export async function onRequestGet({ params, env, request }) {
  const id = String(params.id || "");
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response("Not found", { status: 404 });
  const key = `music/${id}`, head = await env.MUSIC_BUCKET.head(key);
  if (!head) return new Response("Not found", { status: 404 });
  const headers = new Headers({ "Content-Type": head.httpMetadata?.contentType || "audio/mpeg",
    "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=3600", "Content-Disposition": "inline" });
  const range = request.headers.get("Range");
  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!m) return new Response(null, { status: 416 });
    let start, end;
    if (m[1] === "") { const suffix = Number(m[2]); start = Math.max(0, head.size-suffix); end = head.size-1; }
    else { start = Number(m[1]); end = m[2] ? Number(m[2]) : head.size-1; }
    if (start >= head.size || end < start) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${head.size}` } });
    end = Math.min(end, head.size-1); const length = end-start+1;
    const obj = await env.MUSIC_BUCKET.get(key, { range: { offset: start, length } });
    headers.set("Content-Range", `bytes ${start}-${end}/${head.size}`); headers.set("Content-Length", String(length));
    return new Response(obj.body, { status: 206, headers });
  }
  const obj = await env.MUSIC_BUCKET.get(key); headers.set("Content-Length", String(head.size));
  return new Response(obj.body, { headers });
}